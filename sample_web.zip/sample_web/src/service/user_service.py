import pathlib, sys 
import numpy as np 

           
root_path = pathlib.Path(__file__).parent.resolve().parent.resolve()

sys.path.append(str(root_path))

import os
import redis
from flask import Flask, redirect, request,render_template, url_for,session
import json, yaml
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from dao import user

redisConn=redis.Redis('localhost',6379)

app = Flask(__name__, template_folder='../templates')   
app.secret_key='Akshaya@14' 


def get_db_connection():
    Session = sessionmaker(bind=db_engine)
    return Session()

@app.route('/')
def test():
    return render_template("register.html")

@app.route('/register')
def register_page():
    return render_template("register.html")

@app.route('/login')
def login_page():
    return render_template("login.html")

@app.route('/logout')
def logout_page():
    redisConn.delete('login_userId')
    return redirect(url_for('login_page'))

@app.route('/pswd')
def forget_pswd_page():
    return render_template("forget_pswd.html")

@app.route('/chngePswd')
def chnge_pswd_page():
    return render_template("change_pswd.html")

@app.route('/about')
def about_us():
    if redisConn.exists('login_userId'):
        return render_template("about_us.html")
        
    else:
        return redirect(url_for('login_page'))

@app.route('/contact')
def contact_us():
    if redisConn.exists('login_userId'):
        return render_template("contact_us.html")
    else:
       return redirect(url_for('login_page'))

@app.route('/home')
def home():
    if redisConn.exists('login_userId'):
        return render_template("home.html")
    else:
       return redirect(url_for('login_page'))

### adding user to user table while register###
@app.route('/add/user', methods=['POST'])
def add_user():
    res = {
        'status': 'success',
        'message': None,
        'data': None
    }
    try:
        print(type(request))
        input = request.get_json(force=True)
            
                   
        if 'name' not in input:
            res['status'] = 'failure'
            res['message'] = 'No name given'
            return json.dumps(res)
           
        elif 'phnNum' not in input:
            res['status'] = 'failure'
            res['message'] = 'No phone number given'
           
        
        elif 'password' not in input:
            res['status'] = 'failure'
            res['message'] = 'No password given'  
           

        elif 'email' not in input:
            res['status'] = 'failure'
            res['message'] = 'No email given'
           

        else:
            connection = get_db_connection()
            res['data']=user.check_mbleNum_and_email(
                connection=connection,
                phoneNum=input['phnNum'],
                email=input['email']
            )
            
            if(res['data']==None):

                res['data'] = user.add_user(
                    name=input['name'],
                    phoneNum=input['phnNum'],
                    password=input['password'],
                    email=input['email'],
                    connection=connection 
                    )
               
    except Exception as e:
        print(str(e))
        res['status'] = 'failure'
        res['message'] = 'Unable to add the user'
    
    return json.dumps(res)



### getting details for login validation ###
@app.route('/user/login/details', methods=['POST'])
def login_details():
    res = {
        'status': 'success',
        'message': None,
        'data': None
    }
  
    try:
        input = request.get_json(force=True)
        connection = get_db_connection()
        res['data'] = user.get_login_user_details(
            connection, 
            email=input['email'],
            password=input['password']

        )
        
        if(res['data']=="Invalid login details"):
            res['status']="failure"
            res['message']="Either username or password is invalid" 
        else:
            res['status']="success"
            res['message']="user exist"  
            redisConn.set('login_userId',res['data']['id'])  
           
        
    except Exception as e:
        print(str(e))
        res['status'] = 'failure'
        res['message'] = 'Unable to get details'
    
    
    return json.dumps(res)


### getting details for reset pswd validation ###
@app.route('/verify/mail/reset/password', methods=['POST'])
def reset_pswd_mail_v():
    res = {
        'status': 'success',
        'message': None,
        'data': None
    }
    
    try:
        input = request.get_json(force=True)
        connection = get_db_connection()
        res['data'] = user.verify_email_password(
            connection, 
            email=input['email'],
                             
        )
        session['user_id']=res['data']['user_id']
        
       
            
    except Exception as e:
        print(str(e))

        res['status'] = 'failure'
        res['message'] = 'Unable to get details'
        
    return json.dumps(res)


### getting details for change password ###
@app.route('/change/password', methods=['PATCH'])
def change_pswd():
    res = {
        'status': 'success',
        'message': None,
        'data': None
    }
  
    try:
        input = request.get_json(force=True)
        connection = get_db_connection()
       
       
        res['data'] = user.change_password(
            connection, 
            id=session.get('user_id'),
            new_password=input['newPassword']
           
        )
            
    except Exception as e:
        print(str(e))
        res['status'] = 'failure'
        res['message'] = 'Unable to get details'
        
    return json.dumps(res)

file_config = yaml.load(open(os.path.join(root_path, "..", "conf", "config.yml")))
                                       
db_engine = create_engine(file_config['db_connection_path'], pool_size=50, isolation_level="READ COMMITTED")
app.run('localhost', 5000)