from model import user
from operator import and_



def check_mbleNum_and_email(connection,phoneNum,email):
    mobile_obj=connection.query(user.User).filter(user.User.phone_Num==phoneNum).first()
    email_obj=connection.query(user.User).filter(user.User.email==email).first()
   
      
    if mobile_obj is None and email_obj is None:
        return None
    elif mobile_obj is not None and email_obj is not None:
        return "mobile number and email is already exist"
    elif mobile_obj is not None:
        return "mobile number is already exist"
    elif email_obj is not None:
        return "email is already exist"

def add_user(name,phoneNum,password,email,connection):
    obj = user.User(name=name,phone_Num=phoneNum,email=email,password=password)
    connection.add(obj)
    connection.commit()

    return "user registered Successfully"


def get_login_user_details(connection,email,password):
    obj=connection.query(user.User).filter(
        and_(user.User.email==email,user.User.password==password)

    ).first()
    result=None
    if obj is not None:
        result={
            'id':obj.id,
            'name':obj.name,
            'email':obj.email,
            'phone_Num':obj.phone_Num

        }
        return result
   
    return "Invalid login details"

def verify_email_password(connection,email):
    obj=connection.query(user.User).filter(user.User.email==email).first()
        
    if obj is not None:
        result={
            'user_id':obj.id,
            
        }
        return result
   
    return "User Email not exist"


def change_password(connection,id,new_password):
    obj=connection.query(user.User).filter(user.User.id==id).first()
    print(id)  
    print(new_password) 
    if obj is not None:
       obj.password=new_password
       connection.commit()
       return "successfuly changed password"
    return "can't able to update" 


