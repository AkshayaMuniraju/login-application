from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class User(Base):
    __tablename__ = 'user'
    __table_args__ = {'schema': 'user'}

    id = Column('id', Integer, nullable=False, primary_key=True)
    name = Column('name', String, nullable=False)
    phone_Num = Column('phone_Num',Integer, nullable=False)
    password=Column('password',String,nullable=False)
    email=Column('email',String,nullable=False)

